# Ryan Loizzo
# 1/28/18
# Regex Implementation


regex = []
re_pointer = 0
evil_counter = 1

def plus(q):
	q = str(q)
	matches = set("")
	for i in range(31):
		m = ""
		for j in range(i+1):
			m += q
		matches.add(m)
	return matches

def star(q):
	q = str(q)
	matches = set("")
	for i in range(30):
		m = ""
		for j in range(i):
			m += q
		matches.add(m)
	return matches

def dot():
	matches = set("")
	for i in range(48,123):
		matches.add(chr(i))
	return matches

def add(item, re):
	newre = []
	if type(item) is str:
		for r in re:
			r += item
			newre.append(r)
	else:
		for x in item:
			for r in re:
				r += x
				newre.append(r)
	return newre

def evil(q):
	q = str(q)
	open_p = 0
	closed_p = 0
	match = ""
	if len(q) > 7:
		for i in range(len(q)-4):
			if q[i:i+4] == "evil(":
				print("x")
				open_p = i+4
				p = open_p
				while True:
					p += 1
					if q[p] == ")":
						closed_p = p
						break
				m = evil(q[open_p + 1:closed_p - 1])
				match += m
			else:
				m = ""
				for i in range(evil_counter):
					m += q
				evil_counter += 1
				match += m
	return match	
				

def match(string, re):
	if string in re:
		return True
	else:
		return False

if __name__ == "__main__":
	myre = [""]
	myre = add(plus("cat"),myre)
	myre = add(dot(),myre)
	myre = add("d",myre)
	myre = add("o",myre)
	myre = add(star("g"), myre)
	print(match("catcatQdogggggg",myre))
	print(match("turkeybaconcheese",myre))

